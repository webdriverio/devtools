# chromium — 2026-07-27T10:19:43.235Z

1. Page.navigate("https://example.com")
2. Element.getText()
3. assert.equal("Example Domain", "Example Domain")
4. Page.navigate("https://example.org")
5. Page.getTitle()
6. assert.match("Example Domain", "/Example/i")
7. Page.navigate("https://example.com")
8. Element.getText()
9. assert.equal("Example Domain", "This Is Not The Heading")  ERROR: Expected values to be strictly equal:

Expected: 'This Is Not The Heading'
Received: 'Example Domain'
10. Page.navigate("https://example.com")
11. Page.navigate("https://example.com")
12. Page.getTitle()
13. assert.match("Example Domain", "/Example/i")