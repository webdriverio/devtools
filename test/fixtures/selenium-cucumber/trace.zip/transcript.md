# chromium — 2026-07-27T10:20:06.142Z

1. Page.navigate("https://the-internet.herokuapp.com/login")
2. Element.fill("tomsmith")  value="tomsmith"
3. Element.fill("SuperSecretPassword!")  value="SuperSecretPassword!"
4. Element.click()
5. Page.getUrl()
6. Element.getText()
7. assert.match("You logged into a secure area!\n×", "/You logged into a secure area/i")
8. Page.navigate("https://the-internet.herokuapp.com/login")
9. Element.fill("foobar")  value="foobar"
10. Element.fill("barfoo")  value="barfoo"
11. Element.click()
12. Element.getText()
13. assert.match("Your username is invalid!\n×", "/Your username is invalid/i")
14. Page.getUrl()
15. assert.match("https://the-internet.herokuapp.com/log…, "/\\/login$/")