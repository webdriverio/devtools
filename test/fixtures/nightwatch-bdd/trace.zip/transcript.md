# chrome — 2026-07-27T10:20:23.153Z

1. Page.navigate("https://example.com")
2. assert.titleContains("Example")
3. Page.navigate("https://example.org")
4. assert.titleContains("Example")
5. Page.navigate("https://example.com")
6. assert.titleContains("This Is Not The Title")  ERROR: Testing if the page title contains 'This Is Not The Title' in 5000ms - expected "contains 'This Is Not The Title'" but got: "Example Domain" (5131ms)
7. Page.navigate("https://example.com")