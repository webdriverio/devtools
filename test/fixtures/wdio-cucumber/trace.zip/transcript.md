# chrome — 2026-07-27T10:18:40.465Z

1. Page.navigate("https://the-internet.herokuapp.com/login")
2. Element.fill("#username")  value="tomsmith"
3. Element.fill("#password")  value="SuperSecretPassword!"
4. Element.click("button[type="submit"]")
5. assert.toExist()
6. assert.toHaveText("You logged into a secure area!")
7. Page.navigate("https://the-internet.herokuapp.com/login")
8. Element.fill("#username")  value="foobar"
9. Element.fill("#password")  value="barfoo"
10. Element.click("button[type="submit"]")
11. assert.toExist()
12. assert.toHaveText("Your username is invalid!")