# chrome — 2026-07-28T08:23:13.177Z

1. Page.navigate("https://the-internet.herokuapp.com/login")
2. Element.fill("#username")  value="tomsmith"
3. Element.fill("#password")  value="SuperSecretPassword!"
4. Element.click("button[type="submit"]")
5. assert.toExist()
6. assert.toHaveText("You logged into a secure area!")
7. Page.navigate("https://the-internet.herokuapp.com/login")
8. Element.fill("#username")  value="foobar"
9. Element.fill("#password")  value="barfoo"
10. Element.click("button[type="submit"]")
11. assert.toHaveText("Your username is invalid!")  ERROR: Can't call getText on element with selector "#flash" because element wasn't found