# chrome — 2026-07-28T08:25:59.223Z

1. Page.navigate("https://example.org")
2. assert.titleContains("Example")