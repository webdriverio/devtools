# chrome — 2026-07-27T18:54:12.460Z

1. Page.navigate("https://example.org")