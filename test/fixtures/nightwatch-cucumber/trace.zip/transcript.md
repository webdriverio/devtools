# chrome — 2026-07-27T19:31:03.008Z

1. Page.navigate("https://example.org")
2. assert.titleContains("Example")