# chrome — 2026-11-10T06:37:10.720Z

1. Page.navigate("http://127.0.0.1:4567/login")
2. Element.waitForExist("h2")
3. Element.getText()
4. assert.equal("Login Page", "Login Page")
5. Page.navigate("http://127.0.0.1:4567")
6. Page.getTitle()
7. assert.match("The Internet", "/The Internet/")
8. Page.navigate("http://127.0.0.1:4567/login")
9. Element.waitForExist("h2")
10. Element.getText()
11. assert.equal("Login Page", "This Is Not The Heading")  ERROR: Expected values to be strictly equal:

    Expected: 'This Is Not The Heading'
    Received: 'Login Page'
12. Page.navigate("http://127.0.0.1:4567/login")
13. Element.waitForExist("#devtools-never-rendered")  ERROR: Waiting for element to be located By(css selector, #devtools-never-rendered)
    Wait timed out after 1137ms
14. Page.navigate("http://127.0.0.1:4567/login")
15. Page.navigate("http://127.0.0.1:4567/login")
16. Page.getTitle()
17. assert.match("The Internet", "/The Internet/")