# chrome — 2026-10-28T21:44:52.010Z

1. Page.navigate("http://127.0.0.1:4567/login")
2. Element.getText()
3. assert.equal("Login Page", "Login Page")
4. Page.navigate("http://127.0.0.1:4567")
5. Page.getTitle()
6. assert.match("The Internet", "/The Internet/")
7. Page.navigate("http://127.0.0.1:4567/login")
8. Element.getText()
9. assert.equal("Login Page", "This Is Not The Heading")  ERROR: Expected values to be strictly equal:

   Expected: 'This Is Not The Heading'
   Received: 'Login Page'
10. Page.navigate("http://127.0.0.1:4567/login")
11. Browser.waitForFunction("Waiting for element to be located By(css selector, #devtools-never-rendered)")  ERROR: Waiting for element to be located By(css selector, #devtools-never-rendered)
    Wait timed out after 1120ms
12. Page.navigate("http://127.0.0.1:4567/login")
13. Page.navigate("http://127.0.0.1:4567/login")
14. Page.getTitle()
15. assert.match("The Internet", "/The Internet/")