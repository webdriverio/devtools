# chrome — 2026-10-28T21:45:11.427Z

1. Page.navigate("{"url":"http://127.0.0.1:4567/login"}")
2. Element.fill("{"text":"tomsmith","value":["t","o","m","s","m","i","t","h"],"id":"f.742D14747C86DBDBA1C513BADD248F99.d.CEBF4E3C7D57CCC66E9DAAB16684B9B1.e.2"}")  value="[object Object]"
3. Element.fill("{"text":"SuperSecretPassword!","value":["S","u","p","e","r","S","e","c","r","e","t","P","a","s","s","w","o","r","d","!"],"id":"f.742D14747C86DBDBA1C513BADD248F99.d.CEBF4E3C7D57CCC66E9DAAB16684B9B1.e.3"}")  value="[object Object]"
4. Element.click("{"id":"f.742D14747C86DBDBA1C513BADD248F99.d.CEBF4E3C7D57CCC66E9DAAB16684B9B1.e.4"}")
5. Element.getText("{"id":"f.742D14747C86DBDBA1C513BADD248F99.d.9831E87A746BCA0C3A4FB67344DD937D.e.11"}")
6. Page.getUrl()
7. assert.ok("\"/secure\" in current_url")
8. assert.ok("\"You logged into a secure area\" in f…)
9. Element.click("{"id":"f.742D14747C86DBDBA1C513BADD248F99.d.9831E87A746BCA0C3A4FB67344DD937D.e.13"}")
10. Page.getUrl()
11. assert.ok("\"/login\" in current_url")
12. Page.navigate("{"url":"http://127.0.0.1:4567/login"}")
13. Element.fill("{"text":"tomsmith","value":["t","o","m","s","m","i","t","h"],"id":"f.8D1DD0F93A1C8D18FB3BB9EF1415C69B.d.0E25887790809E9D37C9B825965BC35F.e.2"}")  value="[object Object]"
14. Element.fill("{"text":"wrong-password","value":["w","r","o","n","g","-","p","a","s","s","w","o","r","d"],"id":"f.8D1DD0F93A1C8D18FB3BB9EF1415C69B.d.0E25887790809E9D37C9B825965BC35F.e.3"}")  value="[object Object]"
15. Element.click("{"id":"f.8D1DD0F93A1C8D18FB3BB9EF1415C69B.d.0E25887790809E9D37C9B825965BC35F.e.4"}")
16. Element.getText("{"id":"f.8D1DD0F93A1C8D18FB3BB9EF1415C69B.d.3770805972768FCE568F32302BB7EE47.e.15"}")
17. Page.getUrl()
18. assert.ok("\"/login\" in current_url")
19. assert.ok("\"Your password is invalid\" in flash")
20. Page.navigate("{"url":"http://127.0.0.1:4567/login"}")
21. Page.getTitle()
22. assert.equal("title == \"The Internet\"")