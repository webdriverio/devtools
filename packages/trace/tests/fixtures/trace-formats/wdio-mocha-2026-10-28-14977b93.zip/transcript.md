# chrome — 2026-10-28T21:44:31.229Z

1. Page.navigate("http://127.0.0.1:4567/login")
2. Element.fill("#username")  value="tomsmith"
3. Element.fill("#password")  value="SuperSecretPassword!"
4. Element.click("button[type="submit"]")
5. assert.toBeExisting()
6. assert.toHaveText("You logged into a secure area!")
7. Page.navigate("http://127.0.0.1:4567/login")
8. Element.fill("#username")  value="foobar"
9. Element.fill("#password")  value="barfoo"
10. Element.click("button[type="submit"]")
11. assert.toHaveText("Your username is invalid!")