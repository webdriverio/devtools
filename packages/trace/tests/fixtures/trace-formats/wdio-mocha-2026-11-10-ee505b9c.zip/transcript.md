# chrome — 2026-11-10T06:36:34.676Z

1. Page.navigate("http://127.0.0.1:4567/login")
2. Element.fill("#username")  value="foobar"
3. Element.fill("#password")  value="barfoo"
4. Element.click("button[type="submit"]")
5. assert.toHaveText("You logged into a secure area!")  ERROR: Expect $(`#flash`) to have text

   Expected: StringContaining "You logged into a secure area!"
   Received: "Your username is invalid!x"