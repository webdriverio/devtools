# chrome — 2026-11-10T06:37:31.964Z

1. Page.navigate("{"url":"http://127.0.0.1:4567/login"}")
2. Element.waitForDisplayed("visibility_of_element_located(('id', 'username'))")
3. Element.fill("{"text":"tomsmith","value":["t","o","m","s","m","i","t","h"],"id":"f.4068A16D915F7D7467BB985907FB34E9.d.696665285EA3EC6FA92B16CD82B84865.e.2"}")  value="[object Object]"
4. Element.fill("{"text":"SuperSecretPassword!","value":["S","u","p","e","r","S","e","c","r","e","t","P","a","s","s","w","o","r","d","!"],"id":"f.4068A16D915F7D7467BB985907FB34E9.d.696665285EA3EC6FA92B16CD82B84865.e.3"}")  value="[object Object]"
5. Element.click("{"id":"f.4068A16D915F7D7467BB985907FB34E9.d.696665285EA3EC6FA92B16CD82B84865.e.4"}")
6. Element.waitForDisplayed("visibility_of_element_located(('id', 'flash'))")
7. Element.getText("{"id":"f.4068A16D915F7D7467BB985907FB34E9.d.FA739AD98D90063144B5267E909990C2.e.11"}")
8. Page.getUrl()
9. assert.ok("\"/secure\" in current_url")
10. assert.ok("\"You logged into a secure area\" in f…)
11. Element.waitForDisplayed("visibility_of_element_located(('css selector', 'a.button'))")
12. Element.click("{"id":"f.4068A16D915F7D7467BB985907FB34E9.d.FA739AD98D90063144B5267E909990C2.e.13"}")
13. Element.waitForDisplayed("visibility_of_element_located(('id', 'username'))")
14. Page.getUrl()
15. assert.ok("\"/login\" in current_url")
16. Page.navigate("{"url":"http://127.0.0.1:4567/login"}")
17. Element.waitForDisplayed("visibility_of_element_located(('id', 'username'))")
18. Element.fill("{"text":"tomsmith","value":["t","o","m","s","m","i","t","h"],"id":"f.69D74867DD71D4F6213E7B6B2CFC95EA.d.26E9CA630290AF105B2C71C0081A4284.e.2"}")  value="[object Object]"
19. Element.fill("{"text":"wrong-password","value":["w","r","o","n","g","-","p","a","s","s","w","o","r","d"],"id":"f.69D74867DD71D4F6213E7B6B2CFC95EA.d.26E9CA630290AF105B2C71C0081A4284.e.3"}")  value="[object Object]"
20. Element.click("{"id":"f.69D74867DD71D4F6213E7B6B2CFC95EA.d.26E9CA630290AF105B2C71C0081A4284.e.4"}")
21. Element.waitForDisplayed("visibility_of_element_located(('id', 'flash'))")
22. Element.getText("{"id":"f.69D74867DD71D4F6213E7B6B2CFC95EA.d.8C65DD6123FF5178CA76036BBBD79FC0.e.16"}")
23. Page.getUrl()
24. assert.ok("\"/login\" in current_url")
25. assert.ok("\"Your password is invalid\" in flash")
26. Page.navigate("{"url":"http://127.0.0.1:4567/login"}")
27. Element.waitForDisplayed("visibility_of_element_located(('id', 'login'))")
28. Page.getTitle()
29. assert.equal("title == \"The Internet\"")