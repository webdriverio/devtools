# chrome — 2026-11-10T06:37:21.922Z

1. Page.navigate("http://127.0.0.1:4567/login")
2. Element.waitForDisplayed("#username")
3. Element.fill("#username")  value="tomsmith"
4. Element.fill("#password")  value="SuperSecretPassword!"
5. Element.click("button[type="submit"]")
6. Element.waitForDisplayed("#flash")
7. assert.urlContains("/secure")
8. assert.textContains("#flash", "You logged into a secure area")
9. Element.waitForDisplayed("a.button")
10. Element.click("a.button")
11. Element.waitForDisplayed("#username")
12. assert.urlContains("/login")
13. Page.navigate("http://127.0.0.1:4567/login")
14. Element.waitForDisplayed("#username")
15. Element.fill("#username")  value="foobar"
16. Element.fill("#password")  value="barfoo"
17. Element.click("button[type="submit"]")
18. Element.waitForDisplayed("#flash")
19. assert.textContains("#flash", "You logged into a secure area")  ERROR: Testing if element <#flash> contains text 'You logged into a secure area' in 5000ms - expected "contains text 'You logged into a secure area'" but got: "does not contain 'You logged into a secure area'" (5276ms)
20. Page.navigate("http://127.0.0.1:4567/login")
21. Element.waitForDisplayed("#username")